export default {
    AJIOFRONTPAGELOGO : require("../../assets/Images/AjioLogo.jpeg"),
    LOGIN : require("../../assets/Images/login.png"),
    SIGNUP: require("../../assets/Images/register.jpeg")
}