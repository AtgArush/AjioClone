import React, { Component } from 'react'
import {View, Text, TouchableOpacity, Image} from "react-native"
import images from '../../constant/images'
import navigationStrings from '../../constant/navigationStrings'
export default class Login extends Component {
    constructor(props){
        super(props)
        this.state = {

        }
    }
    render() {
        let {navigation} = this.props
        return (
            <View style = {{flex: 1, backgroundColor: "black", display: "flex", justifyContent: "space-around"}}>
                {/* <Text>LandingPage</Text>
                <TouchableOpacity onPress = {()=> navigation.navigate(navigationStrings.TABROUTES)}>
                    <Text>LOGIN</Text>
                </TouchableOpacity> */}
                <View style = {{alignItems: "center"}}>
                {/* <Image style={{resizeMode: "contain", width: 240, height: 100, borderRadius:10}} source = {images.LOGIN} /> */}
                </View>
                <View>
                    
                </View>
            </View>
        )
    }
}
