import React, { Component } from 'react'
import {View, Text} from "react-native"
export default class WishList extends Component {
    render() {
        return (
            <View>
                <Text>WishList</Text>
            </View>
        )
    }
}
