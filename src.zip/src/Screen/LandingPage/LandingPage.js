import React, {Component} from 'react';
import {View, Text, TouchableOpacity, Image} from 'react-native';
import navigationStrings from '../../constant/navigationStrings';
import Images from '../../constant/images';
export default class LandingPage extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }
  render() {
    let {navigation} = this.props;
    return (
      <View
        style={{
          flex: 1,
          display: 'flex',
          flexDirection: 'column',
          backgroundColor: 'black',
        }}>
        <TouchableOpacity
                style={{
                  backgroundColor: 'white',
                  paddingHorizontal: 5,
                  paddingVertical: 10,
                  alignItems: 'center',
                  borderRadius: 20,
                }}
                onPress = {()=> navigation.navigate(navigationStrings.LOGIN)}>
                <Text>LOGIN</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={{
                  backgroundColor: 'white',
                  paddingHorizontal: 5,
                  paddingVertical: 10,
                  alignItems: 'center',
                  borderRadius: 20,
                }}
                onPress = {()=> navigation.navigate(navigationStrings.SIGNUP)}
                >
                <Text>SIGNUP</Text>
              </TouchableOpacity>
      </View>
    );
  }
}
