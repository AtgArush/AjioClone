import React from "react"
import {createStackNavigator} from "@react-navigation/stack"
import {Login, Signup, LandingPage} from "../Screen"
import navigationString from "../constant/navigationStrings"
const Stack = createStackNavigator()

export default function AuthStack(){
    return(
        <React.Fragment>
            <Stack.Screen name = {navigationString.LANDINGPAGE} component = {LandingPage} />
            <Stack.Screen name = {navigationString.LOGIN} component = {Login} />
            <Stack.Screen name = {navigationString.SIGNUP} component = {Signup} />
            {/* <Stack.Screen name = {navigationStrings.} */}
        </React.Fragment>
    )
}