export default {
    LANDINGPAGE: "landingPage",
    LOGIN: "login",
    SIGNUP: "signup",
    TABROUTES: "tabroutes",
    HOMESCREEN: "home",
    ACCOUNT: "account",
    BAG: "bag",
    STORES: "stores",
    WISHLIST: "wishlist",
}