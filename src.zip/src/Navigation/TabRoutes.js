import React from "react"
import {createBottomTabNavigator} from "@react-navigation/bottom-tabs"
import navigationStrings from "../constant/navigationStrings"
import {Home, Account, Bag, Stores, Wishlist} from "../Screen"
const Tab = createBottomTabNavigator()

export default function TabRoutes (){
    return(
        <Tab.Navigator>
            <Tab.Screen name={navigationStrings.HOMESCREEN} component={Home} />
            <Tab.Screen name={navigationStrings.STORES} component={Stores}/>
            <Tab.Screen name={navigationStrings.ACCOUNT} component={Account} />
            <Tab.Screen name={navigationStrings.WISHLIST} component={Wishlist} />
            <Tab.Screen name={navigationStrings.BAG} component={Bag} />

        </Tab.Navigator>
    )
}
