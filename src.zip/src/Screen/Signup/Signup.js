import React, { Component } from 'react'
import {View, Text} from "react-native"
export default class Signup extends Component {
    render() {
        return (
            <View>
                <Text>Signup</Text>
            </View>
        )
    }
}
