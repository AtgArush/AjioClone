import React, { Component } from 'react'
import {View, Text} from "react-native"
export default class Stores extends Component {
    render() {
        return (
            <View>
                <Text>Stores</Text>
            </View>
        )
    }
}
