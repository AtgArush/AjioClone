import React, { Component } from 'react'
import {View, Text} from "react-native"
export default class Bag extends Component {
    render() {
        return (
            <View>
                <Text>Bag</Text>
            </View>
        )
    }
}
