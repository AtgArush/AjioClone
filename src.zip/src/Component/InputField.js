import React from 'react'
import { TextInput } from 'react-native'

export default function InputField(props) {
    return (
        <View>
            <Text></Text>
            <TextInput />
        </View>
    )
}
